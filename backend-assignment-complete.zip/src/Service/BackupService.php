<?php

namespace App\Service;

use Doctrine\DBAL\Connection;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;

class BackupService
{
    private Connection $connection;
    private string $projectDir;

    public function __construct(Connection $connection, string $projectDir)
    {
        $this->connection = $connection;
        $this->projectDir = $projectDir;
    }

    public function createBackup(): array
    {
        try {
            $backupDir = $this->projectDir . '/var/backups';
            if (!is_dir($backupDir)) {
                mkdir($backupDir, 0755, true);
            }

            $timestamp = date('Y-m-d_H-i-s');
            $backupFile = $backupDir . "/backup_{$timestamp}.sql";

            // Get database parameters
            $params = $this->connection->getParams();
            $dbName = $params['dbname'];
            $host = $params['host'];
            $username = $params['user'];
            $password = $params['password'];
            $port = $params['port'] ?? 3306;

            // Create mysqldump command
            $command = sprintf(
                'mysqldump -h%s -P%d -u%s -p%s %s > %s',
                escapeshellarg($host),
                $port,
                escapeshellarg($username),
                escapeshellarg($password),
                escapeshellarg($dbName),
                escapeshellarg($backupFile)
            );

            // Execute backup
            $output = [];
            $returnCode = 0;
            exec($command, $output, $returnCode);

            if ($returnCode !== 0) {
                throw new \RuntimeException('Backup failed: ' . implode('\n', $output));
            }

            // Verify backup file exists and has content
            if (!file_exists($backupFile) || filesize($backupFile) === 0) {
                throw new \RuntimeException('Backup file is empty or was not created');
            }

            return [
                'success' => true,
                'filename' => basename($backupFile),
                'filepath' => $backupFile,
                'size' => filesize($backupFile),
                'created_at' => date('Y-m-d H:i:s'),
                'message' => 'Backup created successfully'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'message' => 'Backup creation failed'
            ];
        }
    }

    public function restoreBackup(string $backupFile): array
    {
        try {
            if (!file_exists($backupFile)) {
                throw new \InvalidArgumentException('Backup file does not exist');
            }

            // Get database parameters
            $params = $this->connection->getParams();
            $dbName = $params['dbname'];
            $host = $params['host'];
            $username = $params['user'];
            $password = $params['password'];
            $port = $params['port'] ?? 3306;

            // Create mysql restore command
            $command = sprintf(
                'mysql -h%s -P%d -u%s -p%s %s < %s',
                escapeshellarg($host),
                $port,
                escapeshellarg($username),
                escapeshellarg($password),
                escapeshellarg($dbName),
                escapeshellarg($backupFile)
            );

            // Execute restore
            $output = [];
            $returnCode = 0;
            exec($command, $output, $returnCode);

            if ($returnCode !== 0) {
                throw new \RuntimeException('Restore failed: ' . implode('\n', $output));
            }

            return [
                'success' => true,
                'filename' => basename($backupFile),
                'restored_at' => date('Y-m-d H:i:s'),
                'message' => 'Database restored successfully'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'message' => 'Database restore failed'
            ];
        }
    }

    public function downloadBackup(string $backupFile): StreamedResponse
    {
        if (!file_exists($backupFile)) {
            throw new \InvalidArgumentException('Backup file does not exist');
        }

        $response = new StreamedResponse();
        $response->setCallback(function () use ($backupFile) {
            $handle = fopen($backupFile, 'rb');
            if ($handle === false) {
                throw new \RuntimeException('Cannot open backup file for reading');
            }

            while (!feof($handle)) {
                echo fread($handle, 8192);
                flush();
            }
            fclose($handle);
        });

        $response->headers->set('Content-Type', 'application/octet-stream');
        $response->headers->set('Content-Disposition', 'attachment; filename="' . basename($backupFile) . '"');
        $response->headers->set('Content-Length', filesize($backupFile));

        return $response;
    }

    public function listBackups(): array
    {
        $backupDir = $this->projectDir . '/var/backups';
        if (!is_dir($backupDir)) {
            return [];
        }

        $backups = [];
        $files = glob($backupDir . '/backup_*.sql');

        foreach ($files as $file) {
            $backups[] = [
                'filename' => basename($file),
                'filepath' => $file,
                'size' => filesize($file),
                'created_at' => date('Y-m-d H:i:s', filemtime($file))
            ];
        }

        // Sort by creation time (newest first)
        usort($backups, function ($a, $b) {
            return strtotime($b['created_at']) - strtotime($a['created_at']);
        });

        return $backups;
    }

    public function deleteBackup(string $filename): array
    {
        $backupDir = $this->projectDir . '/var/backups';
        $backupFile = $backupDir . '/' . $filename;

        if (!file_exists($backupFile)) {
            return [
                'success' => false,
                'error' => 'Backup file does not exist'
            ];
        }

        if (unlink($backupFile)) {
            return [
                'success' => true,
                'message' => 'Backup deleted successfully'
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Failed to delete backup file'
            ];
        }
    }
}
