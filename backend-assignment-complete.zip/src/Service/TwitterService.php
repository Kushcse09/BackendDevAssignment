<?php

namespace App\Service;

use App\Entity\TwitterUser;
use App\Repository\TwitterUserRepository;
use Abraham\TwitterOAuth\TwitterOAuth;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class TwitterService
{
    private string $consumerKey;
    private string $consumerSecret;
    private string $accessToken;
    private string $accessTokenSecret;
    private string $callbackUrl;
    private EntityManagerInterface $entityManager;
    private TwitterUserRepository $twitterUserRepository;
    private SessionInterface $session;

    public function __construct(
        string $consumerKey,
        string $consumerSecret,
        string $accessToken,
        string $accessTokenSecret,
        string $callbackUrl,
        EntityManagerInterface $entityManager,
        TwitterUserRepository $twitterUserRepository,
        SessionInterface $session
    ) {
        $this->consumerKey = $consumerKey;
        $this->consumerSecret = $consumerSecret;
        $this->accessToken = $accessToken;
        $this->accessTokenSecret = $accessTokenSecret;
        $this->callbackUrl = $callbackUrl;
        $this->entityManager = $entityManager;
        $this->twitterUserRepository = $twitterUserRepository;
        $this->session = $session;
    }

    public function getAuthorizationUrl(): string
    {
        $connection = new TwitterOAuth($this->consumerKey, $this->consumerSecret);
        $requestToken = $connection->oauth('oauth/request_token', ['oauth_callback' => $this->callbackUrl]);

        // Store request token in session
        $this->session->set('oauth_token', $requestToken['oauth_token']);
        $this->session->set('oauth_token_secret', $requestToken['oauth_token_secret']);

        return $connection->url('oauth/authorize', ['oauth_token' => $requestToken['oauth_token']]);
    }

    public function handleCallback(string $oauthToken, string $oauthVerifier): ?TwitterUser
    {
        // Get stored request token from session
        $requestToken = $this->session->get('oauth_token');
        $requestTokenSecret = $this->session->get('oauth_token_secret');

        if ($requestToken !== $oauthToken) {
            throw new \InvalidArgumentException('Invalid OAuth token');
        }

        // Get access token
        $connection = new TwitterOAuth($this->consumerKey, $this->consumerSecret, $requestToken, $requestTokenSecret);
        $accessToken = $connection->oauth('oauth/access_token', ['oauth_verifier' => $oauthVerifier]);

        // Create connection with access token
        $connection = new TwitterOAuth(
            $this->consumerKey,
            $this->consumerSecret,
            $accessToken['oauth_token'],
            $accessToken['oauth_token_secret']
        );

        // Get user profile
        $userProfile = $connection->get('account/verify_credentials', ['include_email' => true]);

        if (isset($userProfile->errors)) {
            throw new \RuntimeException('Error fetching user profile: ' . $userProfile->errors[0]->message);
        }

        // Save or update user
        $twitterUser = $this->saveTwitterUser($userProfile, $accessToken);

        // Clear session
        $this->session->remove('oauth_token');
        $this->session->remove('oauth_token_secret');

        return $twitterUser;
    }

    private function saveTwitterUser($userProfile, array $accessToken): TwitterUser
    {
        $existingUser = $this->twitterUserRepository->findByTwitterId($userProfile->id_str);

        if ($existingUser) {
            $twitterUser = $existingUser;
            $twitterUser->setUpdatedAt(new \DateTime());
        } else {
            $twitterUser = new TwitterUser();
        }

        // Set user data
        $twitterUser->setTwitterId($userProfile->id_str);
        $twitterUser->setName($userProfile->name);
        $twitterUser->setUsername($userProfile->screen_name);
        $twitterUser->setEmail($userProfile->email ?? null);
        $twitterUser->setProfileImageUrl($userProfile->profile_image_url_https ?? null);
        $twitterUser->setDescription($userProfile->description ?? null);
        $twitterUser->setFollowersCount($userProfile->followers_count ?? 0);
        $twitterUser->setFollowingCount($userProfile->friends_count ?? 0);
        $twitterUser->setLocation($userProfile->location ?? null);
        $twitterUser->setAccessToken($accessToken['oauth_token']);
        $twitterUser->setAccessTokenSecret($accessToken['oauth_token_secret']);

        $this->entityManager->persist($twitterUser);
        $this->entityManager->flush();

        return $twitterUser;
    }

    public function getUserProfile(TwitterUser $twitterUser): ?object
    {
        $connection = new TwitterOAuth(
            $this->consumerKey,
            $this->consumerSecret,
            $twitterUser->getAccessToken(),
            $twitterUser->getAccessTokenSecret()
        );

        $userProfile = $connection->get('account/verify_credentials');

        if (isset($userProfile->errors)) {
            return null;
        }

        return $userProfile;
    }
}
