<?php

namespace App\Service;

use App\Entity\User;
use App\Repository\UserRepository;
use App\Message\EmailNotification;
use Doctrine\ORM\EntityManagerInterface;
use League\Csv\Reader;
use League\Csv\Statement;
use Symfony\Component\Messenger\MessageBusInterface;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;

class CsvService
{
    private EntityManagerInterface $entityManager;
    private UserRepository $userRepository;
    private ValidatorInterface $validator;
    private MessageBusInterface $messageBus;

    public function __construct(
        EntityManagerInterface $entityManager,
        UserRepository $userRepository,
        ValidatorInterface $validator,
        MessageBusInterface $messageBus
    ) {
        $this->entityManager = $entityManager;
        $this->userRepository = $userRepository;
        $this->validator = $validator;
        $this->messageBus = $messageBus;
    }

    public function processCsvFile(UploadedFile $file): array
    {
        try {
            // Validate file
            $this->validateCsvFile($file);

            // Read CSV
            $csv = Reader::createFromPath($file->getPathname(), 'r');
            $csv->setHeaderOffset(0);

            $records = Statement::create()->process($csv);
            $results = [
                'success' => true,
                'total_records' => 0,
                'processed' => 0,
                'skipped' => 0,
                'errors' => []
            ];

            foreach ($records as $offset => $record) {
                $results['total_records']++;

                try {
                    $user = $this->processRecord($record, $offset);
                    if ($user) {
                        $results['processed']++;

                        // Send async email notification
                        $this->messageBus->dispatch(
                            new EmailNotification(
                                $user->getEmail(),
                                $user->getName(),
                                'welcome'
                            )
                        );
                    } else {
                        $results['skipped']++;
                    }
                } catch (\Exception $e) {
                    $results['errors'][] = [
                        'row' => $offset + 2, // +2 because offset starts at 0 and we have header
                        'error' => $e->getMessage(),
                        'data' => $record
                    ];
                }
            }

            $this->entityManager->flush();

            return $results;
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'total_records' => 0,
                'processed' => 0,
                'skipped' => 0,
                'errors' => []
            ];
        }
    }

    private function validateCsvFile(UploadedFile $file): void
    {
        // Check file extension
        if ($file->getClientOriginalExtension() !== 'csv') {
            throw new \InvalidArgumentException('Only CSV files are allowed');
        }

        // Check file size (max 10MB)
        if ($file->getSize() > 10 * 1024 * 1024) {
            throw new \InvalidArgumentException('File size too large. Maximum 10MB allowed');
        }

        // Check MIME type
        $allowedMimeTypes = ['text/csv', 'text/plain', 'application/csv'];
        if (!in_array($file->getMimeType(), $allowedMimeTypes)) {
            throw new \InvalidArgumentException('Invalid file type. Only CSV files are allowed');
        }
    }

    private function processRecord(array $record, int $offset): ?User
    {
        // Validate required fields
        $requiredFields = ['name', 'email', 'username', 'address', 'role'];
        foreach ($requiredFields as $field) {
            if (!isset($record[$field]) || empty(trim($record[$field]))) {
                throw new \InvalidArgumentException("Missing required field: {$field}");
            }
        }

        // Check if user already exists
        $existingUser = $this->userRepository->findByEmailOrUsername($record['email']);
        if ($existingUser) {
            // Update existing user
            $user = $existingUser;
            $user->setUpdatedAt(new \DateTime());
        } else {
            // Create new user
            $user = new User();
        }

        // Set user data
        $user->setName(trim($record['name']));
        $user->setEmail(trim($record['email']));
        $user->setUsername(trim($record['username']));
        $user->setAddress(trim($record['address']));
        $user->setRole(strtoupper(trim($record['role'])));

        // Validate user entity
        $errors = $this->validator->validate($user);
        if (count($errors) > 0) {
            $errorMessages = [];
            foreach ($errors as $error) {
                $errorMessages[] = $error->getMessage();
            }
            throw new \InvalidArgumentException('Validation errors: ' . implode(', ', $errorMessages));
        }

        $this->entityManager->persist($user);

        return $user;
    }
}
