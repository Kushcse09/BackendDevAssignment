<?php

namespace App\Repository;

use App\Entity\TwitterUser;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<TwitterUser>
 *
 * @method TwitterUser|null find($id, $lockMode = null, $lockVersion = null)
 * @method TwitterUser|null findOneBy(array $criteria, array $orderBy = null)
 * @method TwitterUser[]    findAll()
 * @method TwitterUser[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TwitterUserRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, TwitterUser::class);
    }

    public function save(TwitterUser $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(TwitterUser $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    /**
     * Find Twitter user by Twitter ID
     */
    public function findByTwitterId(string $twitterId): ?TwitterUser
    {
        return $this->createQueryBuilder('tu')
            ->where('tu.twitterId = :twitterId')
            ->setParameter('twitterId', $twitterId)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * Find Twitter user by username
     */
    public function findByUsername(string $username): ?TwitterUser
    {
        return $this->createQueryBuilder('tu')
            ->where('tu.username = :username')
            ->setParameter('username', $username)
            ->getQuery()
            ->getOneOrNullResult();
    }

    /**
     * Find all Twitter users with pagination
     */
    public function findWithPagination(int $page = 1, int $limit = 10): array
    {
        $offset = ($page - 1) * $limit;

        return $this->createQueryBuilder('tu')
            ->orderBy('tu.createdAt', 'DESC')
            ->setMaxResults($limit)
            ->setFirstResult($offset)
            ->getQuery()
            ->getResult();
    }

    /**
     * Count total Twitter users
     */
    public function countTotal(): int
    {
        return $this->createQueryBuilder('tu')
            ->select('COUNT(tu.id)')
            ->getQuery()
            ->getSingleScalarResult();
    }
}
