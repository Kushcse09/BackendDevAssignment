<?php

namespace App\Command;

use App\Entity\User;
use App\Repository\UserRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:seed-database',
    description: 'Seed the database with sample data',
)]
class SeedDatabaseCommand extends Command
{
    private EntityManagerInterface $entityManager;
    private UserRepository $userRepository;

    public function __construct(EntityManagerInterface $entityManager, UserRepository $userRepository)
    {
        $this->entityManager = $entityManager;
        $this->userRepository = $userRepository;
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);

        // Check if data already exists
        if ($this->userRepository->countTotal() > 0) {
            $io->warning('Database already contains data. Skipping seeding.');
            return Command::SUCCESS;
        }

        $io->title('Seeding Database with Sample Data');

        $users = [
            ['John Doe', 'john.doe@example.com', 'johndoe', '123 Main St, City, State 12345', 'USER'],
            ['Jane Smith', 'jane.smith@example.com', 'janesmith', '456 Oak Ave, City, State 67890', 'USER'],
            ['Bob Johnson', 'bob.johnson@example.com', 'bobjohnson', '789 Pine Rd, City, State 54321', 'USER'],
            ['Alice Brown', 'alice.brown@example.com', 'alicebrown', '321 Elm St, City, State 98765', 'USER'],
            ['Charlie Wilson', 'charlie.wilson@example.com', 'charliewilson', '654 Maple Dr, City, State 13579', 'ADMIN'],
            ['Diana Davis', 'diana.davis@example.com', 'dianadavis', '987 Cedar Ln, City, State 24680', 'USER'],
            ['Frank Miller', 'frank.miller@example.com', 'frankmiller', '147 Birch Blvd, City, State 97531', 'USER'],
            ['Grace Taylor', 'grace.taylor@example.com', 'gracetaylor', '258 Walnut Ave, City, State 86420', 'USER'],
            ['Henry Anderson', 'henry.anderson@example.com', 'henryanderson', '369 Ash St, City, State 75319', 'USER'],
            ['Ivy Thomas', 'ivy.thomas@example.com', 'ivythomas', '741 Hickory Ct, City, State 64208', 'ADMIN'],
        ];

        $io->progressStart(count($users));

        foreach ($users as $userData) {
            $user = new User();
            $user->setName($userData[0]);
            $user->setEmail($userData[1]);
            $user->setUsername($userData[2]);
            $user->setAddress($userData[3]);
            $user->setRole($userData[4]);

            $this->entityManager->persist($user);
            $io->progressAdvance();
        }

        $this->entityManager->flush();
        $io->progressFinish();

        $io->success('Successfully seeded database with ' . count($users) . ' users.');

        return Command::SUCCESS;
    }
}
