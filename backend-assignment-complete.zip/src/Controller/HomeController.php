<?php

namespace App\Controller;

use App\Repository\UserRepository;
use App\Repository\TwitterUserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home')]
    public function index(UserRepository $userRepository, TwitterUserRepository $twitterUserRepository): Response
    {
        $stats = [
            'total_users' => $userRepository->countTotal(),
            'total_twitter_users' => $twitterUserRepository->countTotal(),
            'admin_users' => count($userRepository->findByRole('ADMIN')),
            'regular_users' => count($userRepository->findByRole('USER'))
        ];

        return $this->render('home/index.html.twig', [
            'stats' => $stats
        ]);
    }

    #[Route('/dashboard', name: 'app_dashboard')]
    public function dashboard(UserRepository $userRepository, TwitterUserRepository $twitterUserRepository): Response
    {
        $users = $userRepository->findWithPagination(1, 10);
        $twitterUsers = $twitterUserRepository->findWithPagination(1, 10);

        $stats = [
            'total_users' => $userRepository->countTotal(),
            'total_twitter_users' => $twitterUserRepository->countTotal(),
            'admin_users' => count($userRepository->findByRole('ADMIN')),
            'regular_users' => count($userRepository->findByRole('USER'))
        ];

        return $this->render('dashboard/index.html.twig', [
            'users' => $users,
            'twitter_users' => $twitterUsers,
            'stats' => $stats
        ]);
    }

    #[Route('/docs', name: 'app_docs')]
    public function docs(): Response
    {
        return $this->render('docs/index.html.twig');
    }
}
