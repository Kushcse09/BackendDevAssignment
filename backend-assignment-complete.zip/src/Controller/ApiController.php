<?php

namespace App\Controller;

use App\Service\CsvService;
use App\Service\BackupService;
use App\Repository\UserRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/api')]
class ApiController extends AbstractController
{
    #[Route('/upload', name: 'api_upload', methods: ['POST'])]
    #[IsGranted('ROLE_ADMIN')]
    public function uploadCsv(Request $request, CsvService $csvService): JsonResponse
    {
        try {
            $uploadedFile = $request->files->get('file');

            if (!$uploadedFile) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'No file uploaded'
                ], Response::HTTP_BAD_REQUEST);
            }

            $result = $csvService->processCsvFile($uploadedFile);

            $statusCode = $result['success'] ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST;

            return new JsonResponse($result, $statusCode);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    #[Route('/users', name: 'api_users', methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function getUsers(Request $request, UserRepository $userRepository): JsonResponse
    {
        try {
            $page = max(1, $request->query->getInt('page', 1));
            $limit = min(100, max(1, $request->query->getInt('limit', 10)));

            $users = $userRepository->findWithPagination($page, $limit);
            $totalUsers = $userRepository->countTotal();

            $userData = array_map(function ($user) {
                return [
                    'id' => $user->getId(),
                    'name' => $user->getName(),
                    'email' => $user->getEmail(),
                    'username' => $user->getUsername(),
                    'address' => $user->getAddress(),
                    'role' => $user->getRole(),
                    'created_at' => $user->getCreatedAt()->format('Y-m-d H:i:s'),
                    'updated_at' => $user->getUpdatedAt() ? $user->getUpdatedAt()->format('Y-m-d H:i:s') : null
                ];
            }, $users);

            return new JsonResponse([
                'success' => true,
                'data' => $userData,
                'pagination' => [
                    'page' => $page,
                    'limit' => $limit,
                    'total' => $totalUsers,
                    'total_pages' => ceil($totalUsers / $limit)
                ]
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    #[Route('/backup', name: 'api_backup', methods: ['GET'])]
    #[IsGranted('ROLE_ADMIN')]
    public function createBackup(BackupService $backupService): JsonResponse
    {
        try {
            $result = $backupService->createBackup();

            $statusCode = $result['success'] ? Response::HTTP_OK : Response::HTTP_INTERNAL_SERVER_ERROR;

            return new JsonResponse($result, $statusCode);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    #[Route('/restore', name: 'api_restore', methods: ['POST'])]
    #[IsGranted('ROLE_ADMIN')]
    public function restoreBackup(Request $request, BackupService $backupService): JsonResponse
    {
        try {
            $backupFile = $request->files->get('backup_file');

            if (!$backupFile) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'No backup file provided'
                ], Response::HTTP_BAD_REQUEST);
            }

            $result = $backupService->restoreBackup($backupFile->getPathname());

            $statusCode = $result['success'] ? Response::HTTP_OK : Response::HTTP_INTERNAL_SERVER_ERROR;

            return new JsonResponse($result, $statusCode);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    #[Route('/backups', name: 'api_backups_list', methods: ['GET'])]
    #[IsGranted('ROLE_ADMIN')]
    public function listBackups(BackupService $backupService): JsonResponse
    {
        try {
            $backups = $backupService->listBackups();

            return new JsonResponse([
                'success' => true,
                'data' => $backups
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_INTERNAL_SERVER_ERROR);
        }
    }

    #[Route('/backup/{filename}/download', name: 'api_backup_download', methods: ['GET'])]
    #[IsGranted('ROLE_ADMIN')]
    public function downloadBackup(string $filename, BackupService $backupService): Response
    {
        try {
            $backupFile = $this->getParameter('kernel.project_dir') . '/var/backups/' . $filename;

            return $backupService->downloadBackup($backupFile);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage()
            ], Response::HTTP_NOT_FOUND);
        }
    }
}
