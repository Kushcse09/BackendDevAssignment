<?php

namespace App\Controller;

use App\Service\TwitterService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/auth/twitter')]
class TwitterAuthController extends AbstractController
{
    #[Route('', name: 'twitter_auth', methods: ['GET'])]
    public function authenticate(TwitterService $twitterService): Response
    {
        try {
            $authUrl = $twitterService->getAuthorizationUrl();

            // For API requests, return JSON with redirect URL
            if ($this->isApiRequest()) {
                return new JsonResponse([
                    'success' => true,
                    'auth_url' => $authUrl,
                    'message' => 'Redirect user to this URL for Twitter authentication'
                ]);
            }

            // For web requests, redirect to Twitter
            return $this->redirect($authUrl);
        } catch (\Exception $e) {
            if ($this->isApiRequest()) {
                return new JsonResponse([
                    'success' => false,
                    'error' => $e->getMessage()
                ], Response::HTTP_INTERNAL_SERVER_ERROR);
            }

            $this->addFlash('error', 'Authentication failed: ' . $e->getMessage());
            return $this->redirectToRoute('app_home');
        }
    }

    #[Route('/callback', name: 'twitter_callback', methods: ['GET'])]
    public function callback(Request $request, TwitterService $twitterService): Response
    {
        try {
            $oauthToken = $request->query->get('oauth_token');
            $oauthVerifier = $request->query->get('oauth_verifier');

            if (!$oauthToken || !$oauthVerifier) {
                throw new \InvalidArgumentException('Missing OAuth parameters');
            }

            $twitterUser = $twitterService->handleCallback($oauthToken, $oauthVerifier);

            // Store user in session
            $this->getUser(); // This will store the user in session

            // For API requests, return JSON response
            if ($this->isApiRequest()) {
                return new JsonResponse([
                    'success' => true,
                    'user' => [
                        'id' => $twitterUser->getId(),
                        'twitter_id' => $twitterUser->getTwitterId(),
                        'name' => $twitterUser->getName(),
                        'username' => $twitterUser->getUsername(),
                        'email' => $twitterUser->getEmail(),
                        'profile_image_url' => $twitterUser->getProfileImageUrl(),
                        'followers_count' => $twitterUser->getFollowersCount(),
                        'following_count' => $twitterUser->getFollowingCount(),
                        'location' => $twitterUser->getLocation(),
                        'created_at' => $twitterUser->getCreatedAt()->format('Y-m-d H:i:s')
                    ],
                    'message' => 'Authentication successful'
                ]);
            }

            // For web requests, redirect to success page
            $this->addFlash('success', 'Successfully authenticated with Twitter!');
            return $this->render('auth/success.html.twig', [
                'user' => $twitterUser
            ]);

        } catch (\Exception $e) {
            if ($this->isApiRequest()) {
                return new JsonResponse([
                    'success' => false,
                    'error' => $e->getMessage()
                ], Response::HTTP_BAD_REQUEST);
            }

            $this->addFlash('error', 'Authentication failed: ' . $e->getMessage());
            return $this->redirectToRoute('app_home');
        }
    }

    #[Route('/logout', name: 'twitter_logout', methods: ['POST'])]
    public function logout(Request $request): Response
    {
        $request->getSession()->invalidate();

        if ($this->isApiRequest()) {
            return new JsonResponse([
                'success' => true,
                'message' => 'Logged out successfully'
            ]);
        }

        $this->addFlash('success', 'Logged out successfully');
        return $this->redirectToRoute('app_home');
    }

    #[Route('/profile', name: 'twitter_profile', methods: ['GET'])]
    public function profile(Request $request): Response
    {
        $session = $request->getSession();
        $twitterUserId = $session->get('twitter_user_id');

        if (!$twitterUserId) {
            if ($this->isApiRequest()) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'Not authenticated'
                ], Response::HTTP_UNAUTHORIZED);
            }

            return $this->redirectToRoute('twitter_auth');
        }

        // Here you would typically fetch the user from the database
        // For now, we'll return a simple response

        if ($this->isApiRequest()) {
            return new JsonResponse([
                'success' => true,
                'message' => 'User is authenticated',
                'user_id' => $twitterUserId
            ]);
        }

        return $this->render('auth/profile.html.twig');
    }

    private function isApiRequest(): bool
    {
        $request = $this->container->get('request_stack')->getCurrentRequest();
        return $request && (
            $request->headers->get('Accept') === 'application/json' ||
            $request->headers->get('Content-Type') === 'application/json' ||
            str_starts_with($request->getPathInfo(), '/api/')
        );
    }
}
