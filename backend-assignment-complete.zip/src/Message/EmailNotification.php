<?php

namespace App\Message;

class EmailNotification
{
    private string $email;
    private string $name;
    private string $type;
    private array $data;

    public function __construct(string $email, string $name, string $type, array $data = [])
    {
        $this->email = $email;
        $this->name = $name;
        $this->type = $type;
        $this->data = $data;
    }

    public function getEmail(): string
    {
        return $this->email;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getType(): string
    {
        return $this->type;
    }

    public function getData(): array
    {
        return $this->data;
    }
}
