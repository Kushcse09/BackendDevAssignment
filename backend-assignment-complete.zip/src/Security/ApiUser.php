<?php

namespace App\Security;

use Symfony\Component\Security\Core\User\UserInterface;

class ApiUser implements UserInterface
{
    private string $identifier;
    private array $roles;

    public function __construct(string $identifier, array $roles = [])
    {
        $this->identifier = $identifier;
        $this->roles = $roles;
    }

    public function getRoles(): array
    {
        $roles = $this->roles;

        // Add default role
        $roles[] = 'ROLE_USER';

        if ($this->identifier === 'admin') {
            $roles[] = 'ROLE_ADMIN';
        }

        return array_unique($roles);
    }

    public function eraseCredentials(): void
    {
        // Nothing to do
    }

    public function getUserIdentifier(): string
    {
        return $this->identifier;
    }

    public function getUsername(): string
    {
        return $this->getUserIdentifier();
    }
}
