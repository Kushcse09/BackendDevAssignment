<?php

namespace App\MessageHandler;

use App\Message\EmailNotification;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;
use Symfony\Component\Messenger\Attribute\AsMessageHandler;
use Twig\Environment;
use Psr\Log\LoggerInterface;

#[AsMessageHandler]
class EmailNotificationHandler
{
    private MailerInterface $mailer;
    private Environment $twig;
    private LoggerInterface $logger;
    private string $appName;

    public function __construct(
        MailerInterface $mailer,
        Environment $twig,
        LoggerInterface $logger,
        string $appName
    ) {
        $this->mailer = $mailer;
        $this->twig = $twig;
        $this->logger = $logger;
        $this->appName = $appName;
    }

    public function __invoke(EmailNotification $notification): void
    {
        try {
            $email = $this->createEmail($notification);
            $this->mailer->send($email);

            $this->logger->info('Email sent successfully', [
                'email' => $notification->getEmail(),
                'type' => $notification->getType()
            ]);
        } catch (\Exception $e) {
            $this->logger->error('Failed to send email', [
                'email' => $notification->getEmail(),
                'type' => $notification->getType(),
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    private function createEmail(EmailNotification $notification): Email
    {
        $subject = $this->getSubject($notification->getType());
        $template = $this->getTemplate($notification->getType());

        $htmlBody = $this->twig->render($template, [
            'name' => $notification->getName(),
            'email' => $notification->getEmail(),
            'app_name' => $this->appName,
            'data' => $notification->getData()
        ]);

        return (new Email())
            ->from('noreply@backend-assignment.com')
            ->to($notification->getEmail())
            ->subject($subject)
            ->html($htmlBody);
    }

    private function getSubject(string $type): string
    {
        return match ($type) {
            'welcome' => "Welcome to {$this->appName}",
            'backup_created' => "Database Backup Created",
            'restore_completed' => "Database Restore Completed",
            'csv_processed' => "CSV Data Processed",
            default => "Notification from {$this->appName}"
        };
    }

    private function getTemplate(string $type): string
    {
        return match ($type) {
            'welcome' => 'emails/welcome.html.twig',
            'backup_created' => 'emails/backup_created.html.twig',
            'restore_completed' => 'emails/restore_completed.html.twig',
            'csv_processed' => 'emails/csv_processed.html.twig',
            default => 'emails/notification.html.twig'
        };
    }
}
